package com.ropa.paginaropa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaginaRopaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaginaRopaApplication.class, args);
	}

}
