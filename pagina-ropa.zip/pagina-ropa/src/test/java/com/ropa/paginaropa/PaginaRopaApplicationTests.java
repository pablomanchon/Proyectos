package com.ropa.paginaropa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaginaRopaApplicationTests {

	@Test
	void contextLoads() {
	}

}
