package com.ropa.ropamountain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RopaMountainApplicationTests {

	@Test
	void contextLoads() {
	}

}
